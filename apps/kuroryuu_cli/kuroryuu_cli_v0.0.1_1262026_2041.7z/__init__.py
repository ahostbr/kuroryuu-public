"""Kuroryuu CLI - Interactive REPL for local LLMs."""

__version__ = "0.1.0"
